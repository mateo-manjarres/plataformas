﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace silabas
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 x = new Class1("casa");
            Console.WriteLine(x.Analizar());
            Class1 z = new Class1("carros");
            Console.WriteLine(z.Analizar());

            /*
            Console.WriteLine( x.ConsonateNO((char)'a'));
            Console.WriteLine( x.ConsonateNO((char)'e'));
            Console.WriteLine( x.ConsonateNO((char)'i'));
            Console.WriteLine( x.ConsonateNO((char)'o'));
            Console.WriteLine( x.ConsonateNO((char)'u'));
            Console.WriteLine( x.ConsonateNO((char)'j'));
            */
        }
    }
}
