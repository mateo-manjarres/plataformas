﻿using System;

namespace silabas
{
    class Class1
    {
        String palabra, silabasP;
        public Class1(String x)
        {
            palabra = x;//.ToLower();
        }

        public String Analizar()
        {
            Boolean ver = true;
            Char[] letras = new Char[4];
            int i = 0, j = palabra.Length;
            while (ver == true && i < j)
            {
                letras[0] = palabra[i];

                if (i + 1 < j)
                {
                    letras[1] = palabra[i + 1];
                }
                else { letras[1] = (char)0; }

                if (i + 2 < j)
                {
                    letras[2] = palabra[i + 2];
                }
                else { letras[2] = (char)0; }

                if (i + 3 < j)
                {
                    letras[3] = palabra[i + 3];
                }
                else { letras[3] = (char)0; }

                if (i+3!=j) {
                    if (ConsonateNO(letras[0]) == true && ConsonateNO(letras[1]) == true && i + 2 < j)//dos primeras consonante
                    {
                        silabasP += "" + letras[0] + letras[1] + letras[2] + " ";
                        i += 3;
                    }
                    else if (ConsonateNO(letras[3]) == false && i + 3 < j)//cuarta letra es una vocal
                    {
                        silabasP += "" + letras[0] + letras[1] + " " + letras[2] + letras[3] + " ";
                        i += 4;
                    }
                    else if (ConsonateNO(letras[3]) == true && i + 3 < j)//cuarta letra es una consonante
                    {
                        silabasP += "" + letras[0] + letras[1] + letras[2] + " ";
                        i += 3;
                    }
                    else if (ConsonateNO(letras[1]) == false && i + 1 < j)//segunda letra es vocal
                    {
                        silabasP += "" + letras[0] + letras[1] + " ";
                        i += 3;
                    }
                }
                else{
                    if (ConsonateNO(letras[2]) == true)//ultima consonante
                    {
                        silabasP += "" + letras[0] + letras[1] + letras[2];
                        i += 3;
                    }
                    else //ultima vocal
                    {
                        silabasP += "" + letras[0];
                        if(letras[1] != (char)0)
                        {
                            silabasP += "" + letras[1]+" ";
                        }
                            

                        if(letras[2]!= (char)0)
                        {
                            silabasP += "" + letras[2] + " ";
                        }
                        i += 3;
                    }
                }
            }
            return silabasP;
        }

        public Boolean ConsonateNO(Char x)
        {
            if ((x >= (char)98 && x <= (char)100) || (x >= (char)102 && x <= (char)104) ||
                (x >= (char)106 && x <= (char)110) || (x >= (char)112 && x <= (char)116) ||
                (x >= (char)118 && x <= (char)122))
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}