﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace parnNo
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 678;
            if (i % 2 == 0)
            {
                Console.WriteLine(i + " es par");
            }
            else
            {
                Console.WriteLine(i + " es impar");
            }
        }
    }
}
