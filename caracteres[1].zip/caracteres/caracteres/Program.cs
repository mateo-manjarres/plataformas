﻿using System;

namespace caracteres
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 n = new Class1(2, 50, 100);
            n.Imprimir();
            n.Numerito();
        }
    }
}
