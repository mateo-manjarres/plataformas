﻿using System;
using System.Collections.Generic;
using System.Text;

namespace caracteres
{
    class Class1
    {
        int[] conD = new int[3];
        String[] var = new String[5] { "#", "$", "!", "?", "*" };
        String[] numerado;
        int conta = 0;
        public Class1(int x, int y, int z)
        {
            conD[0] = x;
            conD[1] = y;
            conD[2] = z;
            numerado = new String[x * y];
        }

        public void Imprimir()
        {
            int j = 0, k = 0;
            string l = ". ";
            for (int i = 0; i < conD[0]; i++)
            {
                String n = "";
                while (k < conD[1])
                {
                    numerado[conta] = var[j];
                    conta++;
                    n += var[j];
                    if (j < 4)
                    {
                        j++;
                    }
                    else
                    {
                        j = 0;
                    }
                    k++;
                }
                Console.WriteLine(l + n);
                k = 0;
                l += ". ";
            }
        }

        public void Numerito()
        {
            Console.WriteLine(numerado[conD[2]-1]);
        }
    }
}
