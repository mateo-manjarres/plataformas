﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ap1
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 numerito = new Class1(19);
            Console.WriteLine(numerito.Primo());
            Console.WriteLine(numerito.ParNo());
            Console.WriteLine(numerito.Romano());
            Console.WriteLine(numerito.Decimal());

            string x = Console.ReadLine();
        }
    }
}
