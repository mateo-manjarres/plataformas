﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ap1
{
    class Class1
    {
        private readonly int numD, pri;

        public Class1(int num)
        {
            numD = num;
            pri = Primo();
        }

        public int Primo()
        {
            int i, z = 0;
            double x, y = 2;
            while (z < numD)
            {
                i = 1;
                x = 1;
                while (x < y)
                {
                    if (y % x == 0)
                    {
                        i++;
                    }
                    x++;
                }
                if (i == 2)
                {
                    z++;

                }
                y++;
            }
            return (int)y - 1;
        }

        public String ParNo()
        {
            if ((pri / 2)*2 == 0){
                return "par";
            }
            else
            {
                return "impar";
            }
        }

        public string Romano(){
            if (pri > 9999)
            {
                return "numero mayor a 9999";
            }
            else
            {
                String rom = "";
                int i = pri, k;

                if (i > 9)
                {
                    k = i % 10;
                    i = i / 10;
                }
                else
                {
                    k = i;
                    i = 0;
                }

                if (k > 0)
                {
                    switch (k)
                    {
                        case 1:
                            rom = "I";
                            break;
                        case 2:
                            rom = "II";
                            break;
                        case 3:
                            rom = "III";
                            break;
                        case 4:
                            rom = "IV";
                            break;
                        case 5:
                            rom = "V";
                            break;
                        case 6:
                            rom = "VI";
                            break;
                        case 7:
                            rom = "VII";
                            break;
                        case 8:
                            rom = "VIII";
                            break;
                        case 9:
                            rom = "IX";
                            break;
                    }
                }

                if (i > 9)
                {
                    k = i % 10;
                    i = i / 10;
                }
                else
                {
                    k = i;
                    i = 0;
                }

                if (k > 0)
                {
                    switch (k)
                    {
                        case 1:
                            rom = "X" + rom;
                            break;
                        case 2:
                            rom = "XX" + rom;
                            break;
                        case 3:
                            rom = "XXX" + rom;
                            break;
                        case 4:
                            rom = "XL" + rom;
                            break;
                        case 5:
                            rom = "X" + rom;
                            break;
                        case 6:
                            rom = "LX" + rom;
                            break;
                        case 7:
                            rom = "LXX" + rom;
                            break;
                        case 8:
                            rom = "LXXX" + rom;
                            break;
                        case 9:
                            rom = "XC" + rom;
                            break;
                    }
                }

                if (i > 9)
                {
                    k = i % 10;
                    i = i / 10;
                }
                else
                {
                    k = i;
                    i = 0;
                }

                if (k > 0)
                {
                    switch (k)
                    {
                        case 1:
                            rom = "C" + rom;
                            break;
                        case 2:
                            rom = "CC" + rom;
                            break;
                        case 3:
                            rom = "CCC" + rom;
                            break;
                        case 4:
                            rom = "CD" + rom;
                            break;
                        case 5:
                            rom = "D" + rom;
                            break;
                        case 6:
                            rom = "DC" + rom;
                            break;
                        case 7:
                            rom = "DCC" + rom;
                            break;
                        case 8:
                            rom = "DCCC" + rom;
                            break;
                        case 9:
                            rom = "CM" + rom;
                            break;
                    }
                }

                if (i > 9)
                {
                    k = i % 10;
                    i = i / 10;
                }
                else
                {
                    k = i;
                    i = 0;
                }

                if (k > 0)
                {
                    switch (k)
                    {
                        case 1:
                            rom = "M" + rom;
                            break;
                        case 2:
                            rom = "MM" + rom;
                            break;
                        case 3:
                            rom = "MMM" + rom;
                            break;
                        case 4:
                            rom = "-MV" + rom;
                            break;
                        case 5:
                            rom = "-V" + rom;
                            break;
                        case 6:
                            rom = "-VI" + rom;
                            break;
                        case 7:
                            rom = "VII" + rom;
                            break;
                        case 8:
                            rom = "VIII" + rom;
                            break;
                        case 9:
                            rom = "IX" + rom;
                            break;
                    }
                }

                return rom;

            }
        }

        public String Decimal()
        {
            if (pri > 1000000)
            {
                return "numero mayor a 1000000";
            }
            else
            {
                String rom = "";
                int i = pri, k;

                if (i >= 15 && i <= 10)
                {
                    k = i % 100;
                    i = i / 100;
                }
                else if(i > 9)
                {
                    k = i % 10;
                    i = i / 10;
                }
                else
                {
                    k = i;
                    i = 0;
                }

                if (k > 0)
                {
                    switch (k)
                    {
                        case 1:
                            rom = "uno";
                            break;
                        case 2:
                            rom = "dos";
                            break;
                        case 3:
                            rom = "tres";
                            break;
                        case 4:
                            rom = "cuatro";
                            break;
                        case 5:
                            rom = "cinco";
                            break;
                        case 6:
                            rom = "seis";
                            break;
                        case 7:
                            rom = "siete";
                            break;
                        case 8:
                            rom = "ocho";
                            break;
                        case 9:
                            rom = "nueve";
                            break;
                        case 10:
                            rom = "diez";
                            break;
                        case 11:
                            rom = "once";
                            break;
                        case 12:
                            rom = "doce";
                            break;
                        case 13:
                            rom = "trece";
                            break;
                        case 14:
                            rom = "catorce";
                            break;
                        case 15:
                            rom = "quince";
                            break;
                    }
                }

                if (i >= 9)
                {
                    k = i % 10;
                    i = i / 10;
                    rom = " y " + rom;
                }
                else
                {
                    k = i;
                    i = 0;
                }

                if (k > 0)
                {
                    switch (k)
                    {
                        case 2:
                            rom = "veinti" + rom;
                            break;
                        case 3:
                            rom = "treinta" + rom;
                            break;
                        case 4:
                            rom = "cuarenta" + rom;
                            break;
                        case 5:
                            rom = "cincuenta" + rom;
                            break;
                        case 6:
                            rom = "sesenta" + rom;
                            break;
                        case 7:
                            rom = "setenta" + rom;
                            break;
                        case 8:
                            rom = "ochenta" + rom;
                            break;
                        case 9:
                            rom = "noventa" + rom;
                            break;
                    }
                }

                if (i > 9)
                {
                    k = i % 10;
                    i = i / 10;
                }
                else
                {
                    k = i;
                    i = 0;
                }

                if (k > 0)
                {
                    switch (k)
                    {
                        case 1:
                            rom = "ciento" + rom;
                            break;
                        case 2:
                            rom = "docientos" + rom;
                            break;
                        case 3:
                            rom = "trecientos" + rom;
                            break;
                        case 4:
                            rom = "cuatrocientos" + rom;
                            break;
                        case 5:
                            rom = "quinientos" + rom;
                            break;
                        case 6:
                            rom = "seicientos" + rom;
                            break;
                        case 7:
                            rom = "setecientos" + rom;
                            break;
                        case 8:
                            rom = "ochocientos" + rom;
                            break;
                        case 9:
                            rom = "novecientos" + rom;
                            break;
                    }
                }

                if (i > 9)
                {
                    k = i % 10;
                    i = i / 10;
                }
                else
                {
                    k = i;
                    i = 0;
                }

                if (k > 0)
                {
                    switch (k)
                    {
                        case 1:
                            rom = "mil" + rom;
                            break;
                        case 2:
                            rom = "dosmil" + rom;
                            break;
                        case 3:
                            rom = "tresmil" + rom;
                            break;
                        case 4:
                            rom = "cuatromil" + rom;
                            break;
                        case 5:
                            rom = "cincomil" + rom;
                            break;
                        case 6:
                            rom = "seismil" + rom;
                            break;
                        case 7:
                            rom = "sietemil" + rom;
                            break;
                        case 8:
                            rom = "ochomil" + rom;
                            break;
                        case 9:
                            rom = "nuevemil" + rom;
                            break;
                    }
                }

                return rom;

            }
        }
    }
}
