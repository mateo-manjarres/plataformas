﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace triangulito
{
    class Program
    {
        static void Main(string[] args)
        {
            Piramide x = new Piramide();
            x.Dibujar(5, true, true, true);
        }
    }
}
