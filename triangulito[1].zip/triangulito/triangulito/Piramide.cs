﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace triangulito
{
    class Piramide
    {
        public void Dibujar(int x, Boolean y1, Boolean y2, Boolean y3)
        {
            String piramide="";
            for(int i=1; i<=x; i++)
            {
                piramide += Linea(i, x);
                if (y1 == true)
                {
                    piramide += " ";
                    piramide += Linea(i, x);
                }
                piramide += "\n";
            }
            if (y2 == true)
            {
                for (int i = 0; i < x; i++)
                {
                    piramide += Linea(x-i, x);
                    if (y3 == true)
                    {
                        piramide += " ";
                        piramide += Linea(x-i, x);
                    }
                    piramide += "\n";
                }
            }
            Console.WriteLine(piramide);
        }

        public String Linea(int line, int y)
        {
            String lin="";
            for(int i=0; i<y-line; i++)
            {
                lin += " ";
            }
            for(int i=0; i<line; i++)
            {
                if (i > 0)
                {
                    lin += " ";
                }
                lin += line;
            }
            for (int i = 0; i < y - line; i++)
            {
                lin += " ";
            }
            return lin;
        }
    }
}
