﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace palindroma
{
    class Analizar
    {
        String palabra;
        public Analizar(String pal)
        {
            palabra = pal;
        }

        public void buscar()
        {
            Boolean j = true;
            for(int i=0; i<palabra.Length/2; i++)
            {
                if (palabra[i]!=palabra[palabra.Length-i-1])
                {
                    j = false;
                }
            }
            if (j == true)
            {
                Console.WriteLine("palindroma");
            }
            else
            {
                Console.WriteLine("No palindroma");
            }
        }
    }
}
