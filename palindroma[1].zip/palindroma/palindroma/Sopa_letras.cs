﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace palindroma
{
    class Sopa_letras
    {
        String[] palabras;
        String[,] sopa;
        int fila, columna;
        public Sopa_letras(int fi, int co, string[] pal)
        {
            sopa = new string[co, fi];
            palabras = pal;
            fila=fi;
            columna = co;
        }

        public void Crear_sopita()
        {
            for(int i=0; i<palabras.Length; i++)
            {
                String palabra = palabras[i];
                Random pos = new Random();
                int posX = pos.Next(0, fila);
                int posY = pos.Next(0, columna);
                int caso = pos.Next(0, 4);

                switch (caso)
                {
                    case 1:
                        for (int j = 0; j < palabra.Length ; j++)
                        {
                            if(sopa[posX+j, posY] != "")
                            {
                                i--;
                                break;
                            }
                        }
                        for (int j = 0; j < palabra.Length ; j++)
                        {
                            sopa[posX+j, posY] = ""+palabra[j];
                        }
                        break;

                    case 2:
                        for (int j = 0; j < palabra.Length ; j++)
                        {
                            if (sopa[posX, posY+j] != "")
                            {
                                i--;
                                break;
                            }
                        }
                        for (int j = 0; j < palabra.Length ; j++)
                        {
                            sopa[posX, posY+j] = ""+palabra[j];
                        }
                        break;

                    case 3:
                        for (int j = 0; j < palabra.Length ; j++)
                        {
                            if (sopa[posX+j, posY + j] != "")
                            {
                                i--;
                                break;
                            }
                        }
                        for (int j = 0; j < palabra.Length ; j++)
                        {
                            sopa[posX+j, posY + j] = ""+palabra[j];
                        }
                        break;
                }
            }

            for(int i=0; i < fila-1; i++)
            {
                for (int j = 0; j < columna-1; j++)
                {
                    if(sopa[i, j] == null)
                    {
                        sopa[i, j] = "x";
                    }
                }
            }

            for (int i = 0; i < fila - 1; i++)
            {
                for (int j = 0; j < columna - 1; j++)
                {
                    Console.Write(sopa[i, j] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
