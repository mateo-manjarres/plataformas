﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace palindroma
{
    class Program
    {
        static void Main(string[] args)
        {
            // x = new Analizar("orejeo");
            //x.buscar();
            string[] vector = new string[2] { "kjahkd", "uoozh" };
            Sopa_letras y = new Sopa_letras(50, 50, vector);
            y.Crear_sopita();
        }
    }
}
