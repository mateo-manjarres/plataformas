﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Boolean z=true;
            int i=0, j=1, k=6;
            for(int l=0; l<k; l++)
            {
                if (z == true)
                {
                    i += j;
                    z = false;
                }
                else
                {
                    j += i;
                    z = true;
                }
            }
            if (z == true)
            {
                Console.WriteLine(i);
            }
            else
            {
                Console.WriteLine(j);
            }
            
        }
    }
}
